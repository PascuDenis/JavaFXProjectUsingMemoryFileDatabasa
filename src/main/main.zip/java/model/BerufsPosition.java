package model;

public enum BerufsPosition {
    Entwickler, Tester, ProjectManager, TeamLeader;
}
